import { U as Trigger, l as OutboundMessage } from "./intake-zD3ttErX.js";
import { n as SourceContext, t as SourceKind } from "./kind-xaeuI6Xa.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/folder.d.ts
declare const ConfigSchema: z.ZodObject<{
  folders: z.ZodDefault<z.ZodArray<z.ZodObject<{
    id: z.ZodString;
    inbox: z.ZodString;
    outbox: z.ZodString;
  }, z.core.$strict>>>;
  operator: z.ZodDefault<z.ZodString>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
type FolderConfig = z.infer<typeof ConfigSchema>;
/** One mature drop: a lone file, or a task folder whose instruction is `TASK.md`. */
interface FolderDrop {
  /** Path relative to the inbox, with forward slashes; the task key of its Thread. */
  rel: string;
  kind: 'file' | 'task';
  /** Content fingerprint; a changed drop is a new event, an unchanged reread is a duplicate. */
  hash: string;
  at: string;
  text: string;
  /** Files of a task folder, relative to it; a lone file lists itself. */
  files: string[];
}
/** The Trigger of one drop; the operator's drop is an explicit, human, direct request. */
declare function folderTrigger(drop: FolderDrop, row: {
  id: string;
  inbox: string;
  outbox: string;
}, operator: string): Trigger;
/** Reads one inbox entry into a drop, or undefined while it is still being written or holds nothing readable. */
declare function readDrop(inbox: string, name: string, type: 'file' | 'dir'): Promise<FolderDrop | undefined>;
/** Writes one reply as a markdown file under `<outbox>/<ticket>/<message id>.md`; the message id is the idempotency key. */
declare function sendFolder(message: OutboundMessage): Promise<'sent' | 'gone'>;
declare const folderKind: SourceKind<FolderConfig>;
/** Scans one inbox round: mature drops are received once, cursors move only after every covered Trigger is stored. */
declare function pollFolder(ctx: SourceContext, row: {
  id: string;
  inbox: string;
  outbox: string;
}, operator: string, signal: AbortSignal): Promise<{
  read: number;
  received: number;
}>;
/** The polling loop: waits for setup, follows the switch, reports health, and stops at once on abort. */
declare function watchFolder(ctx: SourceContext, signal: AbortSignal): Promise<void>;
declare const name = "dsh-superagent-folder";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { FolderConfig, FolderDrop, apply, folderKind, folderTrigger, inject, name, pollFolder, readDrop, sendFolder, watchFolder };