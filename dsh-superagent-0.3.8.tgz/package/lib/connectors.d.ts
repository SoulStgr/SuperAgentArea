import { t as SourceKind } from "./kind-DPZbnFCi.js";
import { Context } from "@deepseek-ai/cordis";
//#region src/sources/connectors.d.ts
/** The five placeholder kinds, in the catalog order of plan/23: Gitee, WeChat, Telegram, WeCom app and Email. */
declare const connectorKinds: SourceKind[];
declare const name = "dsh-superagent-connectors";
declare const inject: string[];
/** Registers each placeholder kind, so the catalog lists eleven kinds while only folder, remote, QQ, GitHub, Feishu and DingTalk receive work. */
declare function apply(ctx: Context): void;
//#endregion
export { apply, connectorKinds, inject, name };