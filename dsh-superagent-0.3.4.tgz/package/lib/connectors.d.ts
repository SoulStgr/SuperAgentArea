import { t as SourceKind } from "./kind-DVW9SdIS.js";
import { Context } from "@deepseek-ai/cordis";
//#region src/sources/connectors.d.ts
/** The seven placeholder kinds, in the catalog order of plan/23: Gitee, WeChat, DingTalk, QQ, Telegram, WeCom app and Email. */
declare const connectorKinds: SourceKind[];
declare const name = "dsh-superagent-connectors";
declare const inject: string[];
/** Registers each placeholder kind, so the catalog lists ten kinds while only folder, GitHub and Feishu receive work. */
declare function apply(ctx: Context): void;
//#endregion
export { apply, connectorKinds, inject, name };