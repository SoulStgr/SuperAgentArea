import { t as SourceKind } from "./kind-wBo0y7f_.js";
import { Context } from "@deepseek-ai/cordis";
//#region src/sources/connectors.d.ts
/** The four placeholder kinds, in the catalog order of plan/24: Gitee, Telegram, WeCom app and Email. */
declare const connectorKinds: SourceKind[];
declare const name = "dsh-superagent-connectors";
declare const inject: string[];
/** Registers each placeholder kind, so the catalog lists eleven kinds while only folder, remote, QQ, DingTalk, WeChat, GitHub and Feishu receive work. */
declare function apply(ctx: Context): void;
//#endregion
export { apply, connectorKinds, inject, name };