import { n as SourceContext, r as Family, t as SourceKind } from "./kind-wBo0y7f_.js";
import { W as Trigger } from "./intake-BTrQnIXE.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/wechat.d.ts
/** The update cursor of one instance: the opaque `get_updates_buf` value the next poll sends back. */
declare const weixinCursor: Family<string, [instance: string]>;
/** The message ids one instance already received, with their arrival time: a redelivered message is a duplicate. */
declare const weixinSeen: Family<Record<string, number>, [instance: string]>;
/** How long a received message id stays in the duplicate set: seven days, as the plan requires. */
declare const WEIXIN_SEEN_TTL_MS: number;
/** The most ids one instance remembers; the oldest are forgotten first. */
declare const WEIXIN_SEEN_LIMIT = 1000;
declare const ConfigSchema: z.ZodObject<{
  botType: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
type WechatConfig = z.infer<typeof ConfigSchema>;
/** The Trigger of one WeChat message on its instance: the thread is the direct chat with its sender. */
declare function wechatTrigger(message: {
  messageId: string;
  clientId: string;
  text: string;
  fromUserId: string;
  contextToken: string;
  runId: string;
  createdAt: string;
}, instance: string): Trigger;
/** What receiving one message did. */
type WechatReceipt = 'received' | 'duplicate' | 'filtered';
/** The duplicate set after one arrival, with the ids older than the retention window and beyond the size cap forgotten. */
declare function rememberSeen(seen: Record<string, number>, messageId: string, at: number): Record<string, number>;
/**
 * Turns one normalized message into a Trigger and hands it to the Engine. The instance's duplicate set (message ids for
 * seven days) makes a redelivered message a duplicate before the Engine sees it, which also keeps a long-poll restart from
 * asking for the same work twice.
 */
declare function receiveWechat(ctx: SourceContext, instance: string, message: {
  messageId: string;
  clientId: string;
  text: string;
  fromUserId: string;
  contextToken: string;
  runId: string;
  createdAt: string;
}): Promise<WechatReceipt>;
declare const wechatKind: SourceKind<WechatConfig>;
/** One watch loop's options, as the caller injected them; every field has a production default. */
interface WechatWatchOptions {
  fetchImpl?: typeof fetch;
  /** How long one update poll may wait for iLink to answer; its timeout means no messages yet. */
  pollTimeoutMs?: number;
  /** The waits after consecutive failed polls; tests shorten them. */
  backoffMs?: readonly number[];
  /** Consecutive failures after which the instance reports `error` while it keeps retrying. */
  failureThreshold?: number;
  /** How often the loop rereads the configured instances, so a save takes effect without a restart. */
  reconcileSeconds?: number;
}
/**
 * The Source loop: waits for setup, then keeps one iLink long poll per enabled instance that is signed in, following saves,
 * sign-ins and the enable switch without a restart. An enabled instance with no credential reports `paused` with the
 * needs-sign-in health code; each instance reports its own health entry, and stopping the loop stops every poll.
 */
declare function watchWechat(ctx: SourceContext, signal: AbortSignal, options?: WechatWatchOptions): Promise<void>;
declare const name = "dsh-superagent-wechat";
declare const inject: string[];
/** Registers the kind and starts its sign-in/poll loop. `options` injects fakes in tests; production uses iLink over fetch. */
declare function apply(ctx: Context, options?: WechatWatchOptions): void;
//#endregion
export { WEIXIN_SEEN_LIMIT, WEIXIN_SEEN_TTL_MS, WechatConfig, WechatReceipt, WechatWatchOptions, apply, inject, name, receiveWechat, rememberSeen, watchWechat, wechatKind, wechatTrigger, weixinCursor, weixinSeen };