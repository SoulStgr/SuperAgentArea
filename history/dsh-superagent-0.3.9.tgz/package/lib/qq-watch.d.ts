import { n as SourceContext, t as SourceKind } from "./kind-wBo0y7f_.js";
import { W as Trigger } from "./intake-BTrQnIXE.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/im/qq-transport.d.ts
/** The two credentials a bot needs; the App ID and the App Secret from the QQ open platform. */
interface QqCredentials {
  appId: string;
  appSecret: string;
}
/** One inbound text message the bot received, normalized for the Source. */
interface QqMessage {
  /** The message id; a Trigger derives its id from it and the passive reply sends it back as `msg_id`. */
  messageId: string;
  /** The message text as received, without the bot's own mention markers and trimmed. */
  text: string;
  /** The sender as the Policy's `allowed` list names people: the user openid of a direct message or group member. */
  senderId: string;
  senderNick: string;
  /** The conversation kind: a direct message to the bot, or a group mention. */
  kind: 'c2c' | 'group';
  /** The direct chat's user openid, or the group's group openid; the Trigger's Thread is named after it. */
  conversationId: string;
  /** The group openid of a group message; empty for a direct message. */
  groupId: string;
  addressed: boolean;
  /** The message time as an ISO time; empty when QQ sent none. */
  createdAt: string;
  rawEventType: string;
}
/** One outbound message send as the SDK accepts it; the tests' fake bot implements this shape. */
interface QqSendOptions {
  target: {
    scope: 'c2c' | 'group';
    targetId: string;
    msgId?: string;
  };
  msgType?: number;
  content?: string;
  markdown?: {
    content: string;
  };
  extra?: Record<string, unknown>;
}
/** The SDK's answer to one send: the message id QQ assigned. */
interface QqSendResponse {
  id?: string;
  timestamp?: number | string;
}
/** The one operation a reply needs, so the Channel can send through a live bot or a test double. */
interface QqSender {
  send(options: QqSendOptions): Promise<QqSendResponse>;
}
/** The SDK client operations this transport needs, so tests can inject a fake instead of a socket. */
interface QqBotClient extends QqSender {
  on(event: string, handler: (...args: unknown[]) => unknown): unknown;
  start(signal?: AbortSignal): Promise<void>;
  stop?(): void;
}
/** Creates a bot client for one app; the production one loads the `@tencent-connect/qqbot-nodejs` SDK lazily. */
type QqBotFactory = (credentials: QqCredentials & {
  sandbox: boolean;
}) => QqBotClient | Promise<QqBotClient>;
//#endregion
//#region src/sources/qq.d.ts
declare const ConfigSchema: z.ZodObject<{
  appId: z.ZodDefault<z.ZodString>;
  appSecret: z.ZodDefault<z.ZodString>;
  allowedUserIds: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodString, z.ZodArray<z.ZodString>]>>, z.ZodTransform<string[], string | string[]>>;
  sandbox: z.ZodDefault<z.ZodBoolean>;
}, z.core.$strict>;
type QqConfig = z.infer<typeof ConfigSchema>;
/** The Trigger of one QQ message on its instance: the thread is the direct chat's user openid or the group's openid. */
declare function qqTrigger(message: QqMessage, instance: string, config: QqConfig): Trigger;
/** What receiving one message did. */
type QqReceipt = 'received' | 'duplicate' | 'filtered' | 'not-allowed';
/**
 * Turns one normalized message into a Trigger and hands it to the Engine: the allow-list filter of this instance drops a
 * sender it does not name, and a message whose Trigger the Engine already holds is a duplicate rather than an error.
 */
declare function receiveQq(ctx: SourceContext, instance: string, config: QqConfig, message: QqMessage): Promise<QqReceipt>;
declare const qqKind: SourceKind<QqConfig>;
/** One connection's options, as the caller injected them; every field has a production default. */
interface QqWatchOptions {
  botFactory?: QqBotFactory;
  /** How long one gateway handshake may take before the attempt counts as failed. */
  connectTimeoutMs?: number;
  /** The waits after consecutive failed attempts; tests shorten them. */
  backoffMs?: readonly number[];
  /** Consecutive failures after which the instance reports `error` while it keeps retrying. */
  failureThreshold?: number;
  /** How often the loop rereads the configured instances, so a save takes effect without a restart. */
  reconcileSeconds?: number;
}
/**
 * The Source loop: waits for setup, then keeps one gateway connection per enabled and complete instance, following saves and
 * the enable switch without a restart, reports each instance's own health, and stops every connection on abort. An enabled
 * instance whose two credentials are not set reports `paused` with what it waits for instead of counting as a failure.
 */
declare function watchQq(ctx: SourceContext, signal: AbortSignal, options?: QqWatchOptions): Promise<void>;
declare const name = "dsh-superagent-qq";
declare const inject: string[];
/** Registers the kind and starts its gateway loop. `options` injects fake transport pieces in tests; production loads the SDK. */
declare function apply(ctx: Context, options?: QqWatchOptions): void;
//#endregion
export { QqConfig, QqReceipt, QqWatchOptions, apply, inject, name, qqKind, qqTrigger, receiveQq, watchQq };