import { r as SourceContext, t as SourceKind } from "./kind-Cwm5m8Rf.js";
import { G as Trigger } from "./intake-CuaClO0I.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/im/dingtalk-transport.d.ts
/** The two credentials every DingTalk API call needs; the app's Client ID and Client Secret. */
interface DingtalkCredentials {
  clientId: string;
  clientSecret: string;
}
/** One attachment a callback names, before its bytes are fetched: a picture, or a file with the name DingTalk sent. */
interface DingtalkAttachmentRef {
  kind: 'image' | 'file';
  /** The download code DingTalk issued; empty when the callback named none, which makes the attachment unavailable. */
  downloadCode: string;
  /** The file name DingTalk sent for a file; empty when it sent none or for a picture. */
  name: string;
}
/** One inbound message the bot received, normalized for the Source. */
interface DingtalkMessage {
  /** The message id; a Trigger derives its id from it, so a redelivered callback is a duplicate. */
  messageId: string;
  /** The message text as received, without trimming. */
  text: string;
  /** The attachments the callback names, in order; the Source fetches them before the message becomes work. */
  attachments: DingtalkAttachmentRef[];
  /** The sender as the Policy's `allowed` list names people: senderStaffId, or senderId for a user outside the organization. */
  senderStaffId: string;
  senderNick: string;
  conversationId: string;
  conversationType: 'direct' | 'group';
  conversationTitle: string;
  /** Whether the message addresses the bot: a direct message always does, a group message only when it mentions the bot. */
  addressed: boolean;
  /** The message's own reply address; empty when DingTalk sent none or it was not a trusted DingTalk URL. */
  sessionWebhook: string;
  /** When `sessionWebhook` expires, as an ISO time; empty when DingTalk did not say. */
  sessionWebhookExpiresAt: string;
  /** The robot the callback belongs to, as DingTalk names it. */
  robotCode: string;
  /** The group conversation replies by robot API address; empty for a direct message. */
  openConversationId: string;
  /** The message time as an ISO time; empty when DingTalk sent none. */
  createdAt: string;
}
/** One callback envelope from DingTalk's Stream as the SDK hands it over: its headers and the payload's JSON text. */
interface DingtalkStreamEnvelope {
  headers?: {
    messageId?: string;
  } | undefined;
  data?: unknown;
}
/** The DingTalk Stream client operations this transport needs, so tests can inject a fake instead of a socket. */
interface DingtalkStreamClient {
  connected: boolean;
  registerCallbackListener(topic: string, callback: (envelope: DingtalkStreamEnvelope) => void): unknown;
  connect(): Promise<void>;
  disconnect(): void;
  socketCallBackResponse(messageId: string, result: unknown): void;
}
/** A created Stream client and the bot topic it answers. */
interface DingtalkStream {
  client: DingtalkStreamClient;
  topic: string;
}
/** Creates a Stream client for one app; the production one loads the `dingtalk-stream` SDK lazily. */
type DingtalkStreamFactory = (credentials: DingtalkCredentials) => Promise<DingtalkStream>;
//#endregion
//#region src/sources/dingtalk.d.ts
declare const ConfigSchema: z.ZodObject<{
  clientId: z.ZodDefault<z.ZodString>;
  clientSecret: z.ZodDefault<z.ZodString>;
  robotCode: z.ZodDefault<z.ZodString>;
  allowedUserIds: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodString, z.ZodArray<z.ZodString>]>>, z.ZodTransform<string[], string | string[]>>;
}, z.core.$strict>;
type DingtalkConfig = z.infer<typeof ConfigSchema>;
/** One attachment saved under this installation's state directory, as a worker reads it and as a Trigger carries it. */
interface DingtalkSavedAttachment {
  path: string;
  kind: 'image' | 'file';
  name: string;
  mime: string;
  bytes: number;
}
/** Why a message whose attachments could not be received became no Trigger; the Source counts it in the instance's health. */
type DingtalkAttachmentSkip = 'attachment-count' | 'attachment-unavailable' | 'attachment-too-large' | 'attachment-untrusted' | 'attachment-download-failed';
/** How one received message fetches its attachments; the watch loop leaves every default in place. */
interface DingtalkReceiveOptions {
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
}
/** The directory one message's attachments are saved in: `<stateDir>/area/attachments/dingtalk/<instance>/<messageId>`. */
declare function dingtalkAttachmentDirectory(stateDir: string, instance: string, messageId: string): string;
/**
 * The Trigger of one DingTalk message on its instance: the thread is the DingTalk conversation, and the text names every
 * attachment the Source saved for the worker (its absolute path plus kind and MIME type). `meta.attachments` carries the
 * same files as data, so an adapter can read them without parsing the text.
 */
declare function dingtalkTrigger(message: DingtalkMessage, instance: string, config: DingtalkConfig, attachments?: readonly DingtalkSavedAttachment[]): Trigger;
/** What receiving one message did; an attachment skip names why the message became no Trigger. */
type DingtalkReceipt = 'received' | 'duplicate' | 'filtered' | 'not-allowed' | DingtalkAttachmentSkip;
/**
 * Turns one normalized message into a Trigger and hands it to the Engine: the allow-list filter of this instance drops a
 * sender it does not name, its attachments are fetched first (a message whose files cannot be received becomes no Trigger and
 * is counted in the instance's health), and a message whose Trigger the Engine already holds is a duplicate, not an error.
 */
declare function receiveDingtalk(ctx: SourceContext, instance: string, config: DingtalkConfig, message: DingtalkMessage, options?: DingtalkReceiveOptions): Promise<DingtalkReceipt>;
declare const dingtalkKind: SourceKind<DingtalkConfig>;
/** How many files a reply to `instance` could not deliver since this process started; its health detail names the count. */
declare function dingtalkSentAttachmentFailures(instance: string): number;
/** Forgets the recorded outbound file failures (tests). */
declare function clearDingtalkSentAttachmentFailures(): void;
/** One connection's options, as the caller injected them; every field has a production default. */
interface DingtalkWatchOptions {
  streamFactory?: DingtalkStreamFactory;
  /** The `fetch` attachment downloads use; tests inject a fake, production takes the global one. */
  fetchImpl?: typeof fetch;
  /** How long one Stream handshake may take before the attempt counts as failed. */
  connectTimeoutMs?: number;
  /** How often an open connection is checked, and a handshake's `connected` flag polled. */
  probeIntervalMs?: number;
  /** The waits after consecutive failed attempts; tests shorten them. */
  backoffMs?: readonly number[];
  /** Consecutive failures after which the instance reports `error` while it keeps retrying. */
  failureThreshold?: number;
  /** How often the loop rereads the configured instances, so a save takes effect without a restart. */
  reconcileSeconds?: number;
}
/**
 * The Source loop: waits for setup, then keeps one Stream connection per enabled and complete instance, following saves and
 * the enable switch without a restart, reports each instance's own health, and stops every connection on abort. An enabled
 * instance whose three credentials are not set reports `paused` with what it waits for instead of counting as a failure.
 */
declare function watchDingtalk(ctx: SourceContext, signal: AbortSignal, options?: DingtalkWatchOptions): Promise<void>;
declare const name = "dsh-superagentarea-dingtalk";
declare const inject: string[];
/** Registers the kind and starts its Stream loop. `options` injects fake transport pieces in tests; production loads the SDK. */
declare function apply(ctx: Context, options?: DingtalkWatchOptions): void;
//#endregion
export { DingtalkAttachmentSkip, DingtalkConfig, DingtalkReceipt, DingtalkReceiveOptions, DingtalkSavedAttachment, DingtalkWatchOptions, apply, clearDingtalkSentAttachmentFailures, dingtalkAttachmentDirectory, dingtalkKind, dingtalkSentAttachmentFailures, dingtalkTrigger, inject, name, receiveDingtalk, watchDingtalk };