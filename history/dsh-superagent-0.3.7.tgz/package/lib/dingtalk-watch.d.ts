import { n as SourceContext, t as SourceKind } from "./kind-DPZbnFCi.js";
import { W as Trigger } from "./intake-BTrQnIXE.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/im/dingtalk-transport.d.ts
/** The two credentials every DingTalk API call needs; the app's Client ID and Client Secret. */
interface DingtalkCredentials {
  clientId: string;
  clientSecret: string;
}
/** One inbound text message the bot received, normalized for the Source. */
interface DingtalkMessage {
  /** The message id; a Trigger derives its id from it, so a redelivered callback is a duplicate. */
  messageId: string;
  /** The message text as received, without trimming. */
  text: string;
  /** The sender as the Policy's `allowed` list names people: senderStaffId, or senderId for a user outside the organization. */
  senderStaffId: string;
  senderNick: string;
  conversationId: string;
  conversationType: 'direct' | 'group';
  conversationTitle: string;
  /** Whether the message addresses the bot: a direct message always does, a group message only when it mentions the bot. */
  addressed: boolean;
  /** The message's own reply address; empty when DingTalk sent none or it was not a trusted DingTalk URL. */
  sessionWebhook: string;
  /** When `sessionWebhook` expires, as an ISO time; empty when DingTalk did not say. */
  sessionWebhookExpiresAt: string;
  /** The robot the callback belongs to, as DingTalk names it. */
  robotCode: string;
  /** The group conversation replies by robot API address; empty for a direct message. */
  openConversationId: string;
  /** The message time as an ISO time; empty when DingTalk sent none. */
  createdAt: string;
}
/** One callback envelope from DingTalk's Stream as the SDK hands it over: its headers and the payload's JSON text. */
interface DingtalkStreamEnvelope {
  headers?: {
    messageId?: string;
  } | undefined;
  data?: unknown;
}
/** The DingTalk Stream client operations this transport needs, so tests can inject a fake instead of a socket. */
interface DingtalkStreamClient {
  connected: boolean;
  registerCallbackListener(topic: string, callback: (envelope: DingtalkStreamEnvelope) => void): unknown;
  connect(): Promise<void>;
  disconnect(): void;
  socketCallBackResponse(messageId: string, result: unknown): void;
}
/** A created Stream client and the bot topic it answers. */
interface DingtalkStream {
  client: DingtalkStreamClient;
  topic: string;
}
/** Creates a Stream client for one app; the production one loads the `dingtalk-stream` SDK lazily. */
type DingtalkStreamFactory = (credentials: DingtalkCredentials) => Promise<DingtalkStream>;
//#endregion
//#region src/sources/dingtalk.d.ts
declare const ConfigSchema: z.ZodObject<{
  clientId: z.ZodDefault<z.ZodString>;
  clientSecret: z.ZodDefault<z.ZodString>;
  robotCode: z.ZodDefault<z.ZodString>;
  allowedUserIds: z.ZodPipe<z.ZodDefault<z.ZodUnion<readonly [z.ZodString, z.ZodArray<z.ZodString>]>>, z.ZodTransform<string[], string | string[]>>;
}, z.core.$strict>;
type DingtalkConfig = z.infer<typeof ConfigSchema>;
/** The Trigger of one DingTalk message on its instance: the thread is the DingTalk conversation. */
declare function dingtalkTrigger(message: DingtalkMessage, instance: string, config: DingtalkConfig): Trigger;
/** What receiving one message did. */
type DingtalkReceipt = 'received' | 'duplicate' | 'filtered' | 'not-allowed';
/**
 * Turns one normalized message into a Trigger and hands it to the Engine: the allow-list filter of this instance drops a
 * sender it does not name, and a message whose Trigger the Engine already holds is a duplicate rather than an error.
 */
declare function receiveDingtalk(ctx: SourceContext, instance: string, config: DingtalkConfig, message: DingtalkMessage): Promise<DingtalkReceipt>;
declare const dingtalkKind: SourceKind<DingtalkConfig>;
/** One connection's options, as the caller injected them; every field has a production default. */
interface DingtalkWatchOptions {
  streamFactory?: DingtalkStreamFactory;
  /** How long one Stream handshake may take before the attempt counts as failed. */
  connectTimeoutMs?: number;
  /** How often an open connection is checked, and a handshake's `connected` flag polled. */
  probeIntervalMs?: number;
  /** The waits after consecutive failed attempts; tests shorten them. */
  backoffMs?: readonly number[];
  /** Consecutive failures after which the instance reports `error` while it keeps retrying. */
  failureThreshold?: number;
  /** How often the loop rereads the configured instances, so a save takes effect without a restart. */
  reconcileSeconds?: number;
}
/**
 * The Source loop: waits for setup, then keeps one Stream connection per enabled and complete instance, following saves and
 * the enable switch without a restart, reports each instance's own health, and stops every connection on abort. An enabled
 * instance whose three credentials are not set reports `paused` with what it waits for instead of counting as a failure.
 */
declare function watchDingtalk(ctx: SourceContext, signal: AbortSignal, options?: DingtalkWatchOptions): Promise<void>;
declare const name = "dsh-superagent-dingtalk";
declare const inject: string[];
/** Registers the kind and starts its Stream loop. `options` injects fake transport pieces in tests; production loads the SDK. */
declare function apply(ctx: Context, options?: DingtalkWatchOptions): void;
//#endregion
export { DingtalkConfig, DingtalkReceipt, DingtalkWatchOptions, apply, dingtalkKind, dingtalkTrigger, inject, name, receiveDingtalk, watchDingtalk };