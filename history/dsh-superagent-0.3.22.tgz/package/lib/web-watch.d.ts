import { n as Health, r as SourceContext, t as SourceKind } from "./kind-C8YTwGGx.js";
import { G as Trigger } from "./intake-zu2hNCaz.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/web.d.ts
/** How long one request may take, from its first hop to the end of its body. */
declare const WEB_TIMEOUT_MS = 20000;
/** How much of a response body the Source reads; a longer answer is refused rather than buffered. */
declare const WEB_MAX_BYTES: number;
/** How many redirects one request follows; every hop is checked again before it is fetched. */
declare const WEB_MAX_REDIRECTS = 3;
/** The User-Agent every request names, so a feed operator can see where the load comes from. */
declare const WEB_USER_AGENT = "dsh-superagent/web";
/** How long a received item id is remembered. */
declare const WEB_SEEN_TTL_MS: number;
/** How many received item ids are kept; a busier feed forgets its oldest ones first. */
declare const WEB_SEEN_LIMIT = 1000;
/** How much of an item's title, link and summary the Trigger carries. */
declare const WEB_TEXT_CHARS = 8000;
/** The formats one instance may expect; `auto` reads the answer's Content-Type and opening bytes. */
type WebFormat = 'auto' | 'rss' | 'atom' | 'json';
/** The parser a concrete answer is read with. */
type WebFeedFormat = Exclude<WebFormat, 'auto'>;
/** What the first poll does with items that were already in the feed when the instance was added. */
type WebBaseline = 'latest' | 'all';
/** The dot paths a JSON document is read with; an empty item path reads the document's root array. */
interface WebJsonPaths {
  items: string;
  id: string;
  title: string;
  link: string;
  summary: string;
}
/** One instance's reading of its address, as a poll round and its Trigger builder use it. */
interface WebInstance {
  id: string;
  url: string;
  format: WebFormat;
  baseline: WebBaseline;
  maxItemsPerPoll: number;
  paths: WebJsonPaths;
}
/** One item of a feed or JSON document, before it becomes a Trigger. */
interface WebItem {
  id: string;
  title: string;
  link?: string;
  summary?: string;
  publishedAt?: string;
}
/** What one poll round did: what it read, how many new items it received, how many it skipped and how many wait. */
interface WebRound {
  read: number;
  received: number;
  skipped: number;
  deferred: number;
  baseline?: true;
}
/** One page read from the address: where it finally came from, its declared type and its body text. */
interface WebPage {
  url: string;
  contentType: string;
  text: string;
}
/** Resolves a host name to every address it names; tests replace it so no DNS query is made. */
type ResolveHost = (hostname: string) => Promise<{
  address: string;
}[]>;
/** The fetch the Source runs; `manual` redirects are followed by hand so every hop is checked. */
type WebFetch = (url: string, init: {
  method: 'GET';
  redirect: 'manual';
  headers: Record<string, string>;
  signal: AbortSignal;
}) => Promise<Response>;
/** How a polling loop reaches the web: the fetch, DNS resolution and the bounds; tests replace the first two. */
interface WebTransportOptions {
  fetch?: WebFetch;
  resolve?: ResolveHost;
  timeoutMs?: number;
  maxBytes?: number;
}
/**
 * True when `address` is an address no public feed can legitimately live at: IPv4 loopback, private, link-local and
 * "this network" ranges, IPv6 loopback, unique-local (`fc00::/7`) and link-local (`fe80::/10`) ranges, and IPv4-mapped
 * forms of those. The check is the SSRF guard, so it covers every address a host name resolves to.
 */
declare function isPrivateAddress(address: string): boolean;
/** True when `host` is a literal local name rather than a public host name: `localhost` and anything under `.local`. */
declare function isPrivateHost(host: string): boolean;
/**
 * Why `raw` is not usable as a public feed address, or undefined when it is: an absolute http/https URL, without a user
 * name or password, naming neither a local host name nor a private address. A host name is only resolved at fetch time,
 * where every address it names is checked; this save-time check refuses what can be told without one.
 */
declare function webUrlProblem(raw: string): string | undefined;
declare const ConfigSchema: z.ZodObject<{
  url: z.ZodDefault<z.ZodString>;
  format: z.ZodDefault<z.ZodEnum<{
    auto: "auto";
    rss: "rss";
    atom: "atom";
    json: "json";
  }>>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
  baseline: z.ZodDefault<z.ZodEnum<{
    latest: "latest";
    all: "all";
  }>>;
  maxItemsPerPoll: z.ZodDefault<z.ZodNumber>;
  jsonItemsPath: z.ZodDefault<z.ZodString>;
  jsonIdPath: z.ZodDefault<z.ZodString>;
  jsonTitlePath: z.ZodDefault<z.ZodString>;
  jsonLinkPath: z.ZodDefault<z.ZodString>;
  jsonSummaryPath: z.ZodDefault<z.ZodString>;
  operator: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
type WebConfig = z.infer<typeof ConfigSchema>;
/** The instance a stored configuration describes, as `pollWeb` and its Trigger builder read it. */
declare function webInstanceOf(id: string, config: WebConfig): WebInstance;
/** The item id: its own id, else its link, else a hash of its title and summary, so an id-less feed still deduplicates. */
declare function webItemId(rawId: string | undefined, link: string | undefined, title: string, summary: string | undefined): string;
/** The parser `format` names, or the one the answer's Content-Type and opening bytes state. */
declare function detectFormat(contentType: string, text: string): WebFeedFormat;
/** The items of one answer read with an explicit format; a malformed answer throws. */
declare function parseFeed(format: WebFeedFormat, text: string, paths: WebJsonPaths): WebItem[];
/**
 * Fetches one public http(s) address with the Source's own envelope: a 20 s timeout, a manual redirect chain of at most
 * three hops (each hop checked again), a 2 MiB body cap and the `dsh-superagent/web` User-Agent. The address, its
 * resolved addresses and every redirect target pass the SSRF checks; a `file:` or other scheme is refused.
 */
declare function fetchPage(address: string, signal: AbortSignal, options?: WebTransportOptions): Promise<WebPage>;
/** The Trigger of one item on `instance`: its Thread is the item id, the operator is the reporter, and there is no Channel. */
declare function webTrigger(item: WebItem, instance: WebInstance, operator: string, fetchedAt: string): Trigger;
/** Keeps the item ids seen within the last seven days, newest first and at most `WEB_SEEN_LIMIT` of them. */
declare function pruneSeen(seen: Record<string, string>, now: number): Record<string, string>;
/**
 * One poll round: fetch the instance's address, read it in its format, and receive a Trigger for each item it has not
 * received before — at most `maxItemsPerPoll` of them, the rest waiting for the next round. The first round with
 * `baseline: 'latest'` only records the items already there, so adding an address does not open Tickets for old news.
 * Received ids are stored only after every receive of the round, so a failed round is retried without a second Trigger.
 */
declare function pollWeb(ctx: SourceContext, instance: WebInstance, operator: string, signal: AbortSignal, options?: WebTransportOptions): Promise<WebRound>;
/** What one instance's loop has done since startup, for that instance's own health detail. */
interface WebLoopRound extends WebRound {
  failures: number;
  error?: string;
}
/** The health one instance's entry reports: a poll error once it failed three rounds in a row, else the round's counts. */
declare function webHealth(round: WebLoopRound): Health;
/**
 * The polling loop: waits for setup, follows the switch, polls each enabled instance on its own interval, reports each
 * instance's own health, and stops at once on abort. An enabled instance whose address is still empty is paused with what
 * it waits for, rather than counted as a failed poll.
 */
declare function watchWeb(ctx: SourceContext, signal: AbortSignal, options?: WebTransportOptions): Promise<void>;
declare const webKind: SourceKind<WebConfig>;
declare const name = "dsh-superagent-web";
declare const inject: string[];
/** Registers the kind and starts its loop. `options` carries a stand-in fetch and resolver in tests. */
declare function apply(ctx: Context, options?: WebTransportOptions): void;
//#endregion
export { ResolveHost, WEB_MAX_BYTES, WEB_MAX_REDIRECTS, WEB_SEEN_LIMIT, WEB_SEEN_TTL_MS, WEB_TEXT_CHARS, WEB_TIMEOUT_MS, WEB_USER_AGENT, WebBaseline, WebConfig, WebFeedFormat, WebFetch, WebFormat, WebInstance, WebItem, WebJsonPaths, WebPage, WebRound, WebTransportOptions, apply, detectFormat, fetchPage, inject, isPrivateAddress, isPrivateHost, name, parseFeed, pollWeb, pruneSeen, watchWeb, webHealth, webInstanceOf, webItemId, webKind, webTrigger, webUrlProblem };