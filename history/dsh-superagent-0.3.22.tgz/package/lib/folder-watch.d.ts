import { r as SourceContext, t as SourceKind } from "./kind-C8YTwGGx.js";
import { G as Trigger, mt as ProjectHint, u as OutboundMessage } from "./intake-zu2hNCaz.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/folder.d.ts
declare const ConfigSchema: z.ZodObject<{
  inbox: z.ZodDefault<z.ZodString>;
  outbox: z.ZodDefault<z.ZodString>;
  operator: z.ZodDefault<z.ZodString>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
}, z.core.$strict>;
type FolderConfig = z.infer<typeof ConfigSchema>;
/** One configured instance's folders, as the polling loop and its Trigger builder read them. */
interface FolderInstance {
  id: string;
  inbox: string;
  outbox: string;
}
/** One mature drop: a lone file, or a task folder whose instruction is `TASK.md`. */
interface FolderDrop {
  /** Path relative to the inbox, with forward slashes; the task key of its Thread. */
  rel: string;
  kind: 'file' | 'task';
  /** Content fingerprint; a changed drop is a new event, an unchanged reread is a duplicate. */
  hash: string;
  at: string;
  text: string;
  /** Files of a task folder, relative to it; a lone file lists itself. */
  files: string[];
  /** What a task folder's `PROJECT.md` first line states about its Project, when the drop has one. */
  project?: ProjectHint;
}
/** The names a drop itself may call its Project: a `[project]rest` prefix, and the folder's or file's own base name. */
declare function projectNamesOf(rel: string, kind: 'file' | 'task'): string[];
/** The Project a drop's own name states outright: a `[project]rest` or `【project】rest` prefix, which asks when it fits none. */
declare function bracketedProjectName(rel: string): string | undefined;
/**
 * The Trigger of one drop on `instance`: its source and Thread carry the instance id, so `folder:ops` and
 * `folder:dev` keep separate Threads and the thread key is the same string the old row-based key had.
 * The operator's drop is an explicit, human, direct request. Its `PROJECT.md` states the Project outright, a bracketed
 * name states one too, and the drop's plain name and path only help a match.
 */
declare function folderTrigger(drop: FolderDrop, instance: FolderInstance, operator: string): Trigger;
/** Reads one inbox entry into a drop, or undefined while it is still being written or holds nothing readable. */
declare function readDrop(inbox: string, name: string, type: 'file' | 'dir'): Promise<FolderDrop | undefined>;
/**
 * Writes one reply as a markdown file under `<outbox>/<ticket>/<message id>.md`, once per message id. The host's Project
 * question (`purpose: 'question'`) is written to `<outbox>/QUESTION.md` instead, replacing the question it asked before,
 * since its answer is the operator's next drop rather than a reply in a ticket's folder.
 */
declare function sendFolder(message: OutboundMessage): Promise<'sent' | 'gone'>;
declare const folderKind: SourceKind<FolderConfig>;
/** Scans one instance's inbox round: mature drops are received once, cursors move only after every covered Trigger is stored. */
declare function pollFolder(ctx: SourceContext, instance: FolderInstance, operator: string, signal: AbortSignal): Promise<{
  read: number;
  received: number;
}>;
/**
 * The polling loop: waits for setup, follows the switch, polls each enabled instance on its own interval, reports each
 * instance's own health, and stops at once on abort.
 */
declare function watchFolder(ctx: SourceContext, signal: AbortSignal): Promise<void>;
declare const name = "dsh-superagent-folder";
declare const inject: string[];
declare function apply(ctx: Context): void;
//#endregion
export { FolderConfig, FolderDrop, FolderInstance, apply, bracketedProjectName, folderKind, folderTrigger, inject, name, pollFolder, projectNamesOf, readDrop, sendFolder, watchFolder };