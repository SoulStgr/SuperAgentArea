import { r as SourceContext, t as SourceKind } from "./kind-DzWPKhcp.js";
import { G as Trigger, u as OutboundMessage } from "./intake-BcD3Iq_5.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/remote-transport.d.ts
/** What one `sftp` connection authenticates to and which files prove who the host is. */
interface RemoteTarget {
  host: string;
  port: number;
  username: string;
  /** Absolute local path of the private key handed to `sftp` with `-i`. */
  identityFile: string;
  /** Absolute local path of the known_hosts file `sftp` reads with `StrictHostKeyChecking=yes`. */
  knownHosts: string;
  /** Optional `SHA256:...` fingerprint every round first compares against the known_hosts entry. */
  hostKeySha256?: string;
}
/** How one command runs: its stdin, its working directory, how long it may take, and how a stop reaches it. */
interface RunOptions {
  input?: string;
  cwd?: string;
  timeoutMs?: number;
  signal?: AbortSignal;
}
/** Runs one program with an argument array, never through a shell, and returns its captured output. */
type CommandRunner = (program: string, args: readonly string[], options: RunOptions) => Promise<{
  stdout: string;
  stderr: string;
}>;
/** Programs and limits a kind's transport uses; tests replace `run` with a stand-in and production takes the defaults. */
interface TransportOptions {
  run?: CommandRunner;
  timeoutMs?: number;
  signal?: AbortSignal;
}
//#endregion
//#region src/sources/remote.d.ts
declare const ConfigSchema: z.ZodObject<{
  host: z.ZodDefault<z.ZodString>;
  port: z.ZodDefault<z.ZodNumber>;
  username: z.ZodDefault<z.ZodString>;
  identityFile: z.ZodDefault<z.ZodString>;
  knownHosts: z.ZodDefault<z.ZodString>;
  hostKeySha256: z.ZodDefault<z.ZodString>;
  inbox: z.ZodDefault<z.ZodString>;
  outbox: z.ZodDefault<z.ZodString>;
  pollSeconds: z.ZodDefault<z.ZodNumber>;
  maxFileBytes: z.ZodDefault<z.ZodNumber>;
  operator: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
type RemoteConfig = z.infer<typeof ConfigSchema>;
/** One configured instance's connection and folders, as the polling loop and its Trigger builder read them. */
interface RemoteInstance {
  id: string;
  host: string;
  port: number;
  username: string;
  identityFile: string;
  knownHosts: string;
  hostKeySha256?: string;
  inbox: string;
  outbox: string;
  maxFileBytes: number;
}
/** One file read from a remote inbox, before it becomes a Trigger. */
interface RemoteDrop {
  file: string;
  bytes: number;
  hash: string;
  at: string;
  text: string;
  truncated: boolean;
}
/** Why one inbox entry was left for the operator or a later round. */
interface RemoteSkip {
  file: string;
  size?: number;
  reason: 'invalid-name' | 'oversized' | 'not-a-file';
}
/** What one polling round did: what it read, what it received, what it skipped and what waited for the next round. */
interface RemoteRound {
  read: number;
  received: number;
  skipped: RemoteSkip[];
  deferred: number;
}
/** The connection one instance's polls and receipts use. */
declare function remoteTargetOf(instance: RemoteInstance): RemoteTarget;
/** The instance a stored configuration describes, as `pollRemote` and the Trigger builder read it. */
declare function remoteInstanceOf(id: string, config: RemoteConfig): RemoteInstance;
/**
 * The Trigger of one remote drop on `instance`: its source and Thread carry the instance id, so the thread key is
 * `remote:<instance>:<file>`. The operator's drop is an explicit, human, direct request, and the Channel address carries
 * everything a reply needs except any credential: the key's path, never its content.
 */
declare function remoteTrigger(drop: RemoteDrop, instance: RemoteInstance, operator: string): Trigger;
/**
 * One polling round: verifies the pinned host key, lists the inbox, downloads each candidate file into
 * `<stateDir>/area/remote.tmp/<instance>/`, turns its text into a Trigger and receives it, then archives every handled file
 * under `.done`. A file is skipped when it is hidden, not a valid name, or larger than `maxFileBytes`; a round processes at
 * most `ROUND_FILE_LIMIT` files, leaving the rest for the next one. A file stays in the inbox when its round fails, and the
 * per-instance seen hashes keep a reread of a file that was already received from becoming a second Trigger.
 */
declare function pollRemote(ctx: SourceContext, instance: RemoteInstance, operator: string, signal: AbortSignal, options?: TransportOptions): Promise<RemoteRound>;
/**
 * Writes one reply as `<outbox>/<message id>.md` over SFTP. The receipt is a local temporary file only until the transfer
 * ends; a retry of the same message id overwrites the same remote name, so a repeated delivery leaves one file.
 */
declare function sendRemote(message: OutboundMessage, options?: TransportOptions): Promise<'sent' | 'gone'>;
declare const remoteKind: SourceKind<RemoteConfig>;
/**
 * The polling loop: waits for setup, follows the switch, polls each configured instance on its own interval, reports each
 * instance's own health, and stops at once on abort. An enabled instance whose connection fields are still empty is paused
 * with what it waits for, rather than counted as a failed poll.
 */
declare function watchRemote(ctx: SourceContext, signal: AbortSignal, options?: TransportOptions): Promise<void>;
declare const name = "dsh-superagent-remote";
declare const inject: string[];
/** Registers the kind and starts its loop. `options` carries a stand-in transport in tests; production takes sftp from PATH. */
declare function apply(ctx: Context, options?: TransportOptions): void;
//#endregion
export { RemoteConfig, RemoteDrop, RemoteInstance, RemoteRound, RemoteSkip, apply, inject, name, pollRemote, remoteInstanceOf, remoteKind, remoteTargetOf, remoteTrigger, sendRemote, watchRemote };