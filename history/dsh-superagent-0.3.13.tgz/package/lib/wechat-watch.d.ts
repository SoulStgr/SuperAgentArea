import { n as SourceContext, r as Family, t as SourceKind } from "./kind-M1E3V3S-.js";
import { G as Trigger } from "./intake-r8nS3ikW.js";
import { Context } from "@deepseek-ai/cordis";
import { z } from "zod";
//#region src/sources/im/weixin-transport.d.ts
/** The encrypted media descriptor of one iLink attachment: its signed address and the key it is encrypted with. */
interface WeixinMediaRef {
  /** `media.encrypt_query_param`: the signed query value the download address is built from; never logged. */
  encryptQueryParam: string;
  /** `media.full_url`: an alternate signed address, followed only when it is on the trusted CDN host and path. */
  fullUrl: string;
  /** `media.aes_key`: the key as base64, either of its 16 bytes or of its 32 hex digits. */
  aesKey: string;
  /** `aeskey`: the key as 32 hex digits. */
  aeskey: string;
}
/** One attachment iLink named on an inbound message, before its bytes are fetched and decrypted. */
interface WeixinAttachmentRef {
  /** What the attachment is for the worker: a picture, or any other file. */
  kind: 'image' | 'file';
  /** The encrypted address and key; kept internal and never copied into a Trigger, a log line or a health detail. */
  media: WeixinMediaRef;
  /** The `file_item.file_name` iLink sent; a display name only, never a path. Empty for a picture. */
  name: string;
  /** The size iLink declared in bytes (`file_item.len`); 0 when it declared none. Used only to refuse early. */
  bytes: number;
}
/** One inbound message the bot received, normalized for the Source. */
interface WeixinMessage {
  /** The message id; a Trigger derives its id from it, and a reply sends it as `run_id`. */
  messageId: string;
  /** The iLink client id of the inbound message, when it sent one; recorded for dedupe and receipts. */
  clientId: string;
  /** The message text as received, trimmed; empty for a message that only carried an attachment. */
  text: string;
  /** The pictures and files iLink named, in order; the Source fetches and decrypts them before the message is work. */
  attachments: WeixinAttachmentRef[];
  /** The sender as the Policy's `allowed` list names people: the WeChat user id. */
  fromUserId: string;
  /** This Source listens to direct messages only; a group message is a skip. */
  conversationKind: 'dm' | 'group';
  /** Always true: an inbound direct message addresses the bot by construction. */
  addressed: true;
  /** The conversation capability the reply should carry. */
  contextToken: string;
  /** iLink's own run id of the message, when it sent one. */
  runId: string;
  /** The message time as an ISO time; empty when iLink sent none. */
  createdAt: string;
}
//#endregion
//#region src/sources/wechat.d.ts
/** The update cursor of one instance: the opaque `get_updates_buf` value the next poll sends back. */
declare const weixinCursor: Family<string, [instance: string]>;
/** The message ids one instance already received, with their arrival time: a redelivered message is a duplicate. */
declare const weixinSeen: Family<Record<string, number>, [instance: string]>;
/** How long a received message id stays in the duplicate set: seven days, as the plan requires. */
declare const WEIXIN_SEEN_TTL_MS: number;
/** The most ids one instance remembers; the oldest are forgotten first. */
declare const WEIXIN_SEEN_LIMIT = 1000;
declare const ConfigSchema: z.ZodObject<{
  botType: z.ZodDefault<z.ZodString>;
}, z.core.$strict>;
type WechatConfig = z.infer<typeof ConfigSchema>;
/** One attachment saved under this installation's state directory, as a worker reads it and as a Trigger carries it. */
interface WechatSavedAttachment {
  path: string;
  kind: 'image' | 'file';
  name: string;
  mime: string;
  bytes: number;
}
/** Why a message whose attachments could not be received became no Trigger; the Source counts it in the instance's health. */
type WechatAttachmentSkip = 'attachment-count' | 'attachment-unavailable' | 'attachment-too-large' | 'attachment-untrusted' | 'attachment-key' | 'attachment-decrypt' | 'attachment-download-failed';
/** How one received message fetches its attachments; the watch loop leaves every default in place. */
interface WechatReceiveOptions {
  fetchImpl?: typeof fetch;
  signal?: AbortSignal;
}
/** The directory one message's attachments are saved in: `<stateDir>/area/attachments/wechat/<instance>/<messageId>`. */
declare function wechatAttachmentDirectory(stateDir: string, instance: string, messageId: string): string;
/**
 * The Trigger of one WeChat message on its instance: the thread is the direct chat with its sender, and the text names every
 * attachment the Source saved for the worker (its absolute path plus kind and MIME type). `meta.attachments` carries the same
 * files as data, so an adapter can read them without parsing the text; the reply route is unchanged.
 */
declare function wechatTrigger(message: WeixinMessage, instance: string, attachments?: readonly WechatSavedAttachment[]): Trigger;
/** What receiving one message did; an attachment skip names why the message became no Trigger. */
type WechatReceipt = 'received' | 'duplicate' | 'filtered' | WechatAttachmentSkip;
/** The duplicate set after one arrival, with the ids older than the retention window and beyond the size cap forgotten. */
declare function rememberSeen(seen: Record<string, number>, messageId: string, at: number): Record<string, number>;
/**
 * Turns one normalized message into a Trigger and hands it to the Engine. The instance's duplicate set (message ids for
 * seven days) makes a redelivered message a duplicate before the Engine sees it, which also keeps a long-poll restart from
 * asking for the same work twice. A message that carries attachments fetches and saves them first (a message whose files
 * cannot be received becomes no Trigger and is counted in the instance's health).
 */
declare function receiveWechat(ctx: SourceContext, instance: string, message: WeixinMessage, options?: WechatReceiveOptions): Promise<WechatReceipt>;
declare const wechatKind: SourceKind<WechatConfig>;
/** One watch loop's options, as the caller injected them; every field has a production default. */
interface WechatWatchOptions {
  /** The `fetch` update polls and attachment downloads use; tests inject a fake, production takes the global one. */
  fetchImpl?: typeof fetch;
  /** How long one update poll may wait for iLink to answer; its timeout means no messages yet. */
  pollTimeoutMs?: number;
  /** The waits after consecutive failed polls; tests shorten them. */
  backoffMs?: readonly number[];
  /** Consecutive failures after which the instance reports `error` while it keeps retrying. */
  failureThreshold?: number;
  /** How often the loop rereads the configured instances, so a save takes effect without a restart. */
  reconcileSeconds?: number;
}
/**
 * The Source loop: waits for setup, then keeps one iLink long poll per enabled instance that is signed in, following saves,
 * sign-ins and the enable switch without a restart. An enabled instance with no credential reports `paused` with the
 * needs-sign-in health code; each instance reports its own health entry, and stopping the loop stops every poll.
 */
declare function watchWechat(ctx: SourceContext, signal: AbortSignal, options?: WechatWatchOptions): Promise<void>;
declare const name = "dsh-superagent-wechat";
declare const inject: string[];
/** Registers the kind and starts its sign-in/poll loop. `options` injects fakes in tests; production uses iLink over fetch. */
declare function apply(ctx: Context, options?: WechatWatchOptions): void;
//#endregion
export { WEIXIN_SEEN_LIMIT, WEIXIN_SEEN_TTL_MS, WechatAttachmentSkip, WechatConfig, WechatReceipt, WechatReceiveOptions, WechatSavedAttachment, WechatWatchOptions, apply, inject, name, receiveWechat, rememberSeen, watchWechat, wechatAttachmentDirectory, wechatKind, wechatTrigger, weixinCursor, weixinSeen };